from setuptools import setup, find_packages

setup(
    name="model",
    version="0.1",
    packages=find_packages(include=['trainer', 'trainer.*']),
    install_requires=[
        'google-cloud-aiplatform',
        'tensorflow',  # Add other dependencies required
    ],
    include_package_data=True,
    description='Spam classifier training package',
    author='Wafa Bdeir',
    author_email='wafaabdeir1@gmail.com',
    url='https://github.com/Wbdeir90/Portfolio-Wafa.git',
)



